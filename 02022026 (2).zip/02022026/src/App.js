import React from 'react';
import StudentCard from './StudentCard';
import './App.css';

function App() {
  // Store student data in the parent component
  const students = [
    {
      id: 1,
      name: 'Mohammad Ali shaik',
      rollNumber: 'CS101',
      marks: {
        math: 85,
        science: 92,
        english: 78
      }
    },
    {
      id: 2,
      name: 'Shailaja Kanukuntla',
      rollNumber: 'CS102',
      marks: {
        math: 95,
        science: 88,
        english: 91
      }
    },
    {
      id: 3,
      name: 'Usha Sree Gattu',
      rollNumber: 'CS103',
      marks: {
        math: 72,
        science: 68,
        english: 75
      }
    },
    {
      id: 4,
      name: 'Himaja Netha',
      rollNumber: 'CS104',
      marks: {
        math: 88,
        science: 85,
        english: 90
      }
    }
  ];

  return (
    <div className="App">
      <header className="app-header">
        <h1>Student Marks Card System</h1>
        <p>Academic Year 2024-2025</p>
      </header>
      
      <div className="cards-container">
        {/* Pass data to StudentCard using props */}
        {students.map(student => (
          <StudentCard
            key={student.id}
            name={student.name}
            rollNumber={student.rollNumber}
            marks={student.marks}
          />
        ))}
      </div>
    </div>
  );
}

export default App;