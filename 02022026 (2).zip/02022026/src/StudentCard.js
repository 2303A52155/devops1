import React from 'react';
import './StudentCard.css';

function StudentCard(props) {
  // Destructure props for easier access
  const { name, rollNumber, marks } = props;
  
  // Calculate total marks
  const total = marks.math + marks.science + marks.english;
  
  // Calculate grade based on percentage
  const percentage = (total / 300) * 100;
  
  let grade;
  if (percentage >= 90) {
    grade = 'A+';
  } else if (percentage >= 80) {
    grade = 'A';
  } else if (percentage >= 70) {
    grade = 'B';
  } else if (percentage >= 60) {
    grade = 'C';
  } else if (percentage >= 50) {
    grade = 'D';
  } else {
    grade = 'F';
  }

  return (
    <div className="student-card">
      <h2 className="student-name">{name}</h2>
      <p className="roll-number">Roll Number: {rollNumber}</p>
      
      <div className="marks-section">
        <h3>Subject Marks</h3>
        <div className="marks-grid">
          <div className="mark-item">
            <span className="subject">Mathematics:</span>
            <span className="score">{marks.math}/100</span>
          </div>
          <div className="mark-item">
            <span className="subject">Science:</span>
            <span className="score">{marks.science}/100</span>
          </div>
          <div className="mark-item">
            <span className="subject">English:</span>
            <span className="score">{marks.english}/100</span>
          </div>
        </div>
      </div>
      
      <div className="result-section">
        <div className="total">
          <strong>Total:</strong> {total}/300
        </div>
        <div className="percentage">
          <strong>Percentage:</strong> {percentage.toFixed(2)}%
        </div>
        <div className={`grade grade-${grade.replace('+', 'plus')}`}>
          <strong>Grade:</strong> {grade}
        </div>
      </div>
    </div>
  );
}

export default StudentCard;