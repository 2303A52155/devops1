module.exports = (sequelize, DataTypes) => {
  const Enrollment = sequelize.define("Enrollment", {
    courseId: { type: DataTypes.INTEGER, allowNull: false },
    studentEmail: { type: DataTypes.STRING, allowNull: false },
  });
  return Enrollment;
};
