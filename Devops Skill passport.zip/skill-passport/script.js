// ========== UTILITY FUNCTIONS ==========

// Initialize localStorage if not already done
function initializeLocalStorage() {
    if (!localStorage.getItem('workers')) {
        localStorage.setItem('workers', JSON.stringify([]));
    }
    if (!localStorage.getItem('contractors')) {
        localStorage.setItem('contractors', JSON.stringify([]));
    }
}

// Get all workers from localStorage
function getWorkers() {
    return JSON.parse(localStorage.getItem('workers')) || [];
}

// Get all contractors from localStorage
function getContractors() {
    return JSON.parse(localStorage.getItem('contractors')) || [];
}

// Add a new worker
function addWorker(worker) {
    const workers = getWorkers();
    worker.id = Date.now();
    worker.rating = 0;
    worker.reviews = [];
    workers.push(worker);
    localStorage.setItem('workers', JSON.stringify(workers));
    return worker;
}

// Add a new contractor
function addContractor(contractor) {
    const contractors = getContractors();
    contractor.id = Date.now();
    contractor.registeredDate = new Date().toLocaleDateString();
    contractors.push(contractor);
    localStorage.setItem('contractors', JSON.stringify(contractors));
    return contractor;
}

// Get worker by ID
function getWorkerById(id) {
    const workers = getWorkers();
    return workers.find(w => w.id === id);
}

// Update worker rating
function updateWorkerRating(workerId, rating) {
    const workers = getWorkers();
    const worker = workers.find(w => w.id === workerId);
    if (worker) {
        if (!worker.reviews) {
            worker.reviews = [];
        }
        worker.reviews.push(rating);
        worker.rating = worker.reviews.reduce((a, b) => a + b, 0) / worker.reviews.length;
        localStorage.setItem('workers', JSON.stringify(workers));
        return worker;
    }
    return null;
}

// Search workers
function searchWorkers(location = '', skill = '') {
    let workers = getWorkers();
    
    if (location || skill) {
        workers = workers.filter(worker => {
            const matchLocation = !location || worker.location.toLowerCase().includes(location.toLowerCase());
            const matchSkill = !skill || worker.skills.toLowerCase().includes(skill.toLowerCase());
            return matchLocation && matchSkill;
        });
    }
    
    return workers;
}

// Format phone number
function formatPhoneNumber(phone) {
    const cleaned = phone.replace(/\D/g, '');
    if (cleaned.length === 10) {
        return `(${cleaned.slice(0, 3)}) ${cleaned.slice(3, 6)}-${cleaned.slice(6)}`;
    }
    return phone;
}

// Validate email
function isValidEmail(email) {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
}

// Validate phone
function isValidPhone(phone) {
    const phoneRegex = /^[\d\s\-\(\)\+]+$/;
    return phoneRegex.test(phone) && phone.replace(/\D/g, '').length >= 10;
}

// Show notification
function showNotification(message, type = 'info') {
    const notification = document.createElement('div');
    notification.className = `notification notification-${type}`;
    notification.textContent = message;
    notification.style.cssText = `
        position: fixed;
        top: 20px;
        right: 20px;
        background-color: ${type === 'success' ? '#10B981' : type === 'error' ? '#EF4444' : '#3B82F6'};
        color: white;
        padding: 1rem 1.5rem;
        border-radius: 8px;
        box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        z-index: 10000;
        animation: slideIn 0.3s ease;
    `;
    document.body.appendChild(notification);
    
    setTimeout(() => {
        notification.style.animation = 'fadeOut 0.3s ease';
        setTimeout(() => {
            document.body.removeChild(notification);
        }, 300);
    }, 3000);
}

// ========== SAMPLE DATA ==========

// Function to add sample workers (for demonstration)
function addSampleWorkers() {
    const workers = getWorkers();
    
    // Only add sample data if no workers exist
    if (workers.length === 0) {
        const sampleWorkers = [
            {
                id: 1001,
                name: "John Smith",
                email: "john.smith@email.com",
                phone: "555-0101",
                location: "New York, NY",
                skills: "Carpentry, Framing, Drywall Installation",
                experience: 10,
                rating: 4.8,
                reviews: [5, 4.8, 4.9, 4.7, 4.8]
            },
            {
                id: 1002,
                name: "Maria Garcia",
                email: "maria.garcia@email.com",
                phone: "555-0102",
                location: "Los Angeles, CA",
                skills: "Electrical Work, Lighting Installation, Panel Upgrade",
                experience: 8,
                rating: 4.6,
                reviews: [4.5, 4.7, 4.6, 4.8]
            },
            {
                id: 1003,
                name: "David Johnson",
                email: "david.johnson@email.com",
                phone: "555-0103",
                location: "Chicago, IL",
                skills: "Plumbing, Heating, Drainage",
                experience: 15,
                rating: 4.9,
                reviews: [5, 4.9, 4.8, 5, 4.9]
            },
            {
                id: 1004,
                name: "Sarah Williams",
                email: "sarah.williams@email.com",
                phone: "555-0104",
                location: "Houston, TX",
                skills: "Roofing, Waterproofing, Deck Construction",
                experience: 12,
                rating: 4.7,
                reviews: [4.6, 4.8, 4.7, 4.7]
            },
            {
                id: 1005,
                name: "Michael Brown",
                email: "michael.brown@email.com",
                phone: "555-0105",
                location: "New York, NY",
                skills: "Concrete Work, Foundation, Paving",
                experience: 20,
                rating: 4.5,
                reviews: [4.4, 4.5, 4.5, 4.6]
            },
            {
                id: 1006,
                name: "Jessica Martinez",
                email: "jessica.martinez@email.com",
                phone: "555-0106",
                location: "Los Angeles, CA",
                skills: "Painting, Drywall, Interior Finishing",
                experience: 7,
                rating: 4.8,
                reviews: [4.8, 4.8, 4.9]
            }
        ];
        
        localStorage.setItem('workers', JSON.stringify(sampleWorkers));
    }
}

// ========== INITIALIZATION ==========

// Initialize when DOM is ready
document.addEventListener('DOMContentLoaded', function() {
    initializeLocalStorage();
    addSampleWorkers(); // Add sample data for demonstration
});

// Export functions for use in other files
if (typeof module !== 'undefined' && module.exports) {
    module.exports = {
        getWorkers,
        getContractors,
        addWorker,
        addContractor,
        getWorkerById,
        updateWorkerRating,
        searchWorkers,
        formatPhoneNumber,
        isValidEmail,
        isValidPhone,
        showNotification,
        initializeLocalStorage
    };
}
