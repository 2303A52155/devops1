# React Personal Finance Tracker - Docker Setup

A production-ready React frontend with environment-based Docker configuration, supporting both development and production deployments with proper environment variable management.

## 📋 Table of Contents

- [Overview](#overview)
- [Project Structure](#project-structure)
- [Prerequisites](#prerequisites)
- [Quick Start](#quick-start)
- [Environment Configuration](#environment-configuration)
- [Docker Build Guide](#docker-build-guide)
- [Running Containers](#running-containers)
- [Testing](#testing)
- [Troubleshooting](#troubleshooting)
- [Best Practices](#best-practices)

## 🎯 Overview

This project demonstrates a professional React application Dockerization with:

- ✅ Environment-based configuration (dev/prod)
- ✅ Build-time environment variable injection
- ✅ Runtime environment variable support
- ✅ Multi-stage Docker builds for optimization
- ✅ Environment validation and error handling
- ✅ Docker Compose orchestration
- ✅ Health checks and monitoring
- ✅ Cross-platform helper scripts (Bash/Windows)

## 📁 Project Structure

```
react-finance-app/
├── public/
│   └── index.html                 # HTML entry point
├── src/
│   ├── config/
│   │   └── apiConfig.js           # Configuration module
│   ├── App.js                     # Main React component
│   ├── App.css                    # Component styles
│   ├── index.js                   # React initialization
│   └── index.css                  # Global styles
├── .env                           # Default environment variables
├── .env.dev                       # Development configuration
├── .env.prod                      # Production configuration
├── .env.docker                    # Docker build arguments
├── .dockerignore                  # Docker exclusions
├── .gitignore                     # Git exclusions
├── Dockerfile                     # Production Dockerfile (multi-stage)
├── Dockerfile.dev                 # Development Dockerfile
├── docker-compose.yml             # Development orchestration
├── docker-compose.prod.yml        # Production orchestration
├── package.json                   # Node.js dependencies
├── build-docker.sh / .bat         # Build helper script
├── run-docker.sh / .bat           # Run helper script
├── test-setup.sh                  # Validation script
├── test-full-stack.sh             # Full integration test
├── validate-env.js                # Node.js validation
└── README.md                      # This file
```

## 🔧 Prerequisites

- **Docker Desktop** (v20.10+) - [Download](https://www.docker.com/products/docker-desktop)
- **Docker Compose** (v2.0+) - Usually included with Docker Desktop
- **Node.js** (v18+) - For local development (optional)
- **Git** - For version control

### Verify Installation

```bash
# Check Docker version
docker --version
#Docker version 20.10.0, build ...

# Check Docker Compose version
docker-compose --version
# Docker Compose version v2.0.0

# Check if Docker daemon is running
docker ps
# Should show running containers (or empty list)
```

## ⚡ Quick Start

### Using Docker Compose (Recommended)

```bash
# Navigate to project directory
cd react-finance-app

# Development mode (with hot reload)
docker-compose up

# In another terminal, run tests
./test-setup.sh finance-tracker-dev http://localhost:5000

# Production mode
docker-compose -f docker-compose.prod.yml up

# Stop containers
docker-compose down
```

### Using Docker CLI Directly

```bash
# Build development image
docker build -f Dockerfile.dev \
  --build-arg REACT_APP_API_URL=http://localhost:5000 \
  -t react-finance-app:dev .

# Run development container
docker run -p 3000:3000 \
  -e REACT_APP_API_URL=http://localhost:5000 \
  react-finance-app:dev

# Build production image
docker build \
  --build-arg REACT_APP_API_URL=https://api.example.com \
  --build-arg REACT_APP_ENVIRONMENT=production \
  --build-arg NODE_ENV=production \
  -t react-finance-app:prod .

# Run production container
docker run -p 3000:3000 \
  -e REACT_APP_API_URL=https://api.example.com \
  react-finance-app:prod
```

## 🌍 Environment Configuration

### Environment Variables

The application supports the following environment variables:

| Variable | Type | Default | Description |
|----------|------|---------|-------------|
| `REACT_APP_API_URL` | **Required** | N/A | Backend API endpoint URL |
| `REACT_APP_ENVIRONMENT` | Optional | development | Environment name (dev/prod) |
| `REACT_APP_DEBUG` | Optional | false | Enable debug logging |
| `NODE_ENV` | Optional | development | Node.js environment |

### File-Based Configuration

#### .env (Default)
```env
REACT_APP_API_URL=http://localhost:5000
REACT_APP_ENVIRONMENT=development
REACT_APP_DEBUG=false
```

#### .env.dev (Development)
```env
REACT_APP_API_URL=http://localhost:5000
REACT_APP_ENVIRONMENT=development
REACT_APP_DEBUG=true
```

#### .env.prod (Production)
```env
REACT_APP_API_URL=https://api.finance-tracker.com
REACT_APP_ENVIRONMENT=production
REACT_APP_DEBUG=false
```

### Configuration in Code

The `src/config/apiConfig.js` module handles configuration:

```javascript
import apiConfig from './config/apiConfig';

// Get API URL
const apiUrl = apiConfig.getApiUrl();

// Get full configuration
const config = apiConfig.getConfig();
// Returns: {
//   apiUrl: 'http://localhost:5000',
//   environment: 'development',
//   isDevelopment: true,
//   isProduction: false,
//   allEnvVars: {...}
// }

// Check environment
if (apiConfig.isDevelopment()) {
  console.log('Running in development mode');
}

// Log configuration
apiConfig.logConfig();
```

### Validation

Environment variables are validated at multiple points:

1. **Build Time** (Dockerfile):
   ```dockerfile
   RUN echo "REACT_APP_API_URL: $REACT_APP_API_URL"
   ```

2. **Runtime** (Container startup):
   ```bash
   /app/validate-env.sh
   ```

3. **Application Load** (App component):
   ```javascript
   apiConfig.validateEnvironment(); // Throws if required vars missing
   ```

## 🐳 Docker Build Guide

### Using Helper Script (Recommended)

#### Linux/Mac:
```bash
# Development build
./build-docker.sh -e development -a http://localhost:5000

# Production build
./build-docker.sh -e production -a https://api.example.com -t v1.0.0
```

#### Windows:
```batch
REM Development build
build-docker.bat -e development -a http://localhost:5000

REM Production build
build-docker.bat -e production -a https://api.example.com -t v1.0.0
```

### Manual Docker Build

```bash
# Development image
docker build -f Dockerfile.dev \
  --build-arg REACT_APP_API_URL=http://localhost:5000 \
  --build-arg REACT_APP_ENVIRONMENT=development \
  --build-arg REACT_APP_DEBUG=true \
  --build-arg NODE_ENV=development \
  -t react-finance-app:dev .

# Production image
docker build \
  --build-arg REACT_APP_API_URL=https://api.example.com \
  --build-arg REACT_APP_ENVIRONMENT=production \
  --build-arg REACT_APP_DEBUG=false \
  --build-arg NODE_ENV=production \
  -t react-finance-app:prod .
```

### Build Arguments

| Argument | Used At | Description |
|----------|---------|-------------|
| `REACT_APP_API_URL` | Build-time | Backend API endpoint |
| `REACT_APP_ENVIRONMENT` | Build-time | Environment identifier |
| `REACT_APP_DEBUG` | Build-time | Debug mode flag |
| `NODE_ENV` | Build-time | Node.js environment |

## 🚀 Running Containers

### Using Helper Script (Recommended)

#### Linux/Mac:
```bash
# Development (foreground)
./run-docker.sh react-finance-app:dev

# Production (detached)
./run-docker.sh -e production \
  -a https://api.example.com \
  -d \
  react-finance-app:prod

# With custom container name and port
./run-docker.sh -n my-app -p 8080 react-finance-app:dev
```

#### Windows:
```batch
REM Development (foreground)
run-docker.bat react-finance-app:dev

REM Production (detached)
run-docker.bat -e production ^
  -a https://api.example.com ^
  -d ^
  react-finance-app:prod

REM With custom options
run-docker.bat -n my-app -p 8080 react-finance-app:dev
```

### Manual Docker Run

```bash
# Development with hot reload
docker run -it -p 3000:3000 \
  -e REACT_APP_API_URL=http://localhost:5000 \
  -e REACT_APP_ENVIRONMENT=development \
  -v $(pwd)/src:/app/src \
  react-finance-app:dev

# Production
docker run -d -p 3000:3000 \
  --name finance-tracker \
  -e REACT_APP_API_URL=https://api.example.com \
  -e REACT_APP_ENVIRONMENT=production \
  --restart unless-stopped \
  react-finance-app:prod
```

### Run Options

| Flag | Description |
|------|-------------|
| `-p 3000:3000` | Port mapping |
| `-e VAR=VALUE` | Environment variable |
| `-d` | Detached mode |
| `-it` | Interactive terminal |
| `-v /path:/path` | Volume mount |
| `--name <name>` | Container name |
| `--restart unless-stopped` | Restart policy |

## ✅ Testing

### Test Container Setup

```bash
# Test with running container ID
./test-setup.sh <container_id> http://localhost:5000

# Example:
docker run -d react-finance-app:dev
# d4f8e9c2a1b5 (container ID returned)
./test-setup.sh d4f8e9c2a1b5 http://localhost:5000
```

### Full Stack Testing

```bash
./test-full-stack.sh
```

This script:
1. ✓ Checks Docker daemon
2. ✓ Verifies Docker Compose
3. ✓ Starts all services
4. ✓ Tests React app connectivity
5. ✓ Validates API configuration
6. ✓ Cleanup

### Manual Testing

```bash
# Test with curl (inside container)
docker exec <container_id> curl -f http://localhost:3000

# Check environment variables
docker exec <container_id> env | grep REACT_APP

# View logs
docker logs <container_id>

# Interactive shell
docker exec -it <container_id> sh
```

### HTTP Testing

```bash
# Test app is running
curl -f http://localhost:3000

# Check health endpoint (if configured)
curl -f http://localhost:3000/health

# View page content
curl http://localhost:3000 | head -20
```

## 🔍 Troubleshooting

### Issue: "REACT_APP_API_URL is not set"

**Cause**: Environment variable not passed to container.

**Solution**:
```bash
# Ensure -e flag is used
docker run -p 3000:3000 \
  -e REACT_APP_API_URL=http://localhost:5000 \
  react-finance-app:dev

# Or in docker-compose.yml
environment:
  - REACT_APP_API_URL=http://localhost:5000
```

### Issue: "Connection refused" to API

**Cause**: Container can't reach backend API host.

**Solution**:
```bash
# Use host machine IP (not localhost inside container)
docker run -p 3000:3000 \
  -e REACT_APP_API_URL=http://host.docker.internal:5000 \
  react-finance-app:dev

# Or use Docker network
docker network create finance-net
docker run --network finance-net ...
```

### Issue: Container exits immediately

**Cause**: Build or runtime error.

**Solution**:
```bash
# Check logs
docker logs <container_id>

# Run with interactive terminal
docker run -it react-finance-app:dev

# Validate environment
docker exec <container_id> node validate-env.js
```

### Issue: Port already in use

**Cause**: Port 3000 already occupied.

**Solution**:
```bash
# Use different port
docker run -p 8080:3000 react-finance-app:dev

# Find process using port
lsof -i :3000  # Mac/Linux
netstat -ano | findstr :3000  # Windows

# Stop conflicting container
docker stop <container_id>
```

### Issue: Node modules errors

**Cause**: Corrupted or outdated dependencies.

**Solution**:
```bash
# Rebuild without cache
docker build --no-cache -f Dockerfile.dev -t react-finance-app:dev .

# Clear Docker build cache
docker builder prune
```

## 📚 Best Practices

### 1. Environment Variables
```javascript
// ✓ Good: Validate at startup
if (!process.env.REACT_APP_API_URL) {
  throw new Error('REACT_APP_API_URL is required');
}

// ✗ Bad: Silent failures
const apiUrl = process.env.REACT_APP_API_URL || '';
```

### 2. Docker Images
```bash
# ✓ Good: Use specific base image version
FROM node:18-alpine

# ✗ Bad: Use latest
FROM node:latest
```

### 3. Multi-Stage Builds
```dockerfile
# ✓ Good: Separate build and runtime
FROM node AS builder
RUN npm ci && npm run build

FROM node
COPY --from=builder /app/build ./build

# ✗ Bad: Include build tools in final image
FROM node
RUN npm ci && npm run build
```

### 4. Health Checks
```dockerfile
# ✓ Good: Include health check
HEALTHCHECK --interval=30s CMD curl -f http://localhost:3000

# ✗ Bad: No health check
```

### 5. Security
```yaml
# ✓ Good: Don't run as root
USER node

# ✗ Bad: Run as root
# (default)
```

### 6. Configuration Management
```bash
# ✓ Good: Use environment-specific files
.env.dev
.env.prod
docker-compose.yml
docker-compose.prod.yml

# ✗ Bad: Hardcoded values in code
const API_URL = 'http://production-api.com';
```

### 7. Logging
```javascript
// ✓ Good: Structure logging with context
console.log('API Connection Status:', {
  url: apiConfig.getApiUrl(),
  environment: apiConfig.getEnvironment(),
  timestamp: new Date().toISOString()
});

// ✗ Bad: Generic logs
console.log('Connected');
```

## 🎓 Learning Resources

- [Docker Documentation](https://docs.docker.com/)
- [Docker Compose Guide](https://docs.docker.com/compose/)
- [React Environment Variables](https://create-react-app.dev/docs/adding-custom-environment-variables/)
- [Node.js Best Practices](https://nodejs.org/en/docs/guides/)
- [Container Best Practices](https://docs.docker.com/develop/dev-best-practices/)

## 📝 License

MIT License - Feel free to use this project as a template.

## 🤝 Support

For issues or questions:
1. Check the Troubleshooting section
2. Review Docker logs: `docker logs <container_id>`
3. Validate environment: `node validate-env.js`
4. Check Docker daemon status: `docker ps`

---

**Happy Containerizing! 🚀**
