@REM Docker Build Helper Script for Windows
@REM This script helps build Docker images with proper environment variable injection

@echo off
setlocal enabledelayedexpansion

REM Colors (limited in Windows CMD)
set "GREEN=[92m"
set "RED=[91m"
set "YELLOW=[93m"
set "BLUE=[94m"
set "NC=[0m"

REM Default values
set "ENVIRONMENT=development"
set "API_URL="
set "IMAGE_TAG=latest"
set "REGISTRY="

REM Parse arguments
:parse_args
if "%1"=="" goto parse_end
if "%1"=="-e" (
    set "ENVIRONMENT=%2"
    shift
    shift
    goto parse_args
)
if "%1"=="--environment" (
    set "ENVIRONMENT=%2"
    shift
    shift
    goto parse_args
)
if "%1"=="-a" (
    set "API_URL=%2"
    shift
    shift
    goto parse_args
)
if "%1"=="--api-url" (
    set "API_URL=%2"
    shift
    shift
    goto parse_args
)
if "%1"=="-t" (
    set "IMAGE_TAG=%2"
    shift
    shift
    goto parse_args
)
if "%1"=="--tag" (
    set "IMAGE_TAG=%2"
    shift
    shift
    goto parse_args
)
if "%1"=="-r" (
    set "REGISTRY=%2"
    shift
    shift
    goto parse_args
)
if "%1"=="--registry" (
    set "REGISTRY=%2"
    shift
    shift
    goto parse_args
)
if "%1"=="-h" (
    goto help
)
if "%1"=="--help" (
    goto help
)
shift
goto parse_args

:parse_end

REM Validate API URL
if "!API_URL!"=="" (
    if "!ENVIRONMENT!"=="production" (
        echo Error: API URL is required for production build
        exit /b 1
    ) else (
        set "API_URL=http://localhost:5000"
        echo Warning: No API URL specified, using default: !API_URL!
    )
)

REM Set other variables based on environment
if "!ENVIRONMENT!"=="production" (
    set "DEBUG=false"
    set "NODE_ENV=production"
    set "DOCKERFILE=Dockerfile"
) else (
    set "DEBUG=true"
    set "NODE_ENV=development"
    set "DOCKERFILE=Dockerfile.dev"
)

REM Build Docker image name
set "IMAGE_NAME=react-finance-app"
if not "!REGISTRY!"=="" (
    set "FULL_IMAGE_NAME=!REGISTRY!/!IMAGE_NAME!:!IMAGE_TAG!"
) else (
    set "FULL_IMAGE_NAME=!IMAGE_NAME!:!IMAGE_TAG!"
)

REM Display build information
echo.
echo Docker Build Configuration
echo ================================
echo Environment: !ENVIRONMENT!
echo API URL: !API_URL!
echo Debug Mode: !DEBUG!
echo Node Environment: !NODE_ENV!
echo Dockerfile: !DOCKERFILE!
echo Image Name: !FULL_IMAGE_NAME!
echo.

REM Build Docker image
echo Building Docker image...
docker build ^
    -f !DOCKERFILE! ^
    -t !FULL_IMAGE_NAME! ^
    --build-arg REACT_APP_API_URL=!API_URL! ^
    --build-arg REACT_APP_ENVIRONMENT=!ENVIRONMENT! ^
    --build-arg REACT_APP_DEBUG=!DEBUG! ^
    --build-arg NODE_ENV=!NODE_ENV! ^
    .

if !errorlevel! equ 0 (
    echo.
    echo Docker image built successfully!
    echo Run the image with:
    echo   docker run -p 3000:3000 !FULL_IMAGE_NAME!
) else (
    echo.
    echo Docker build failed!
    exit /b 1
)

goto end

:help
echo Usage: build-docker.bat [OPTIONS]
echo.
echo Options:
echo   -e, --environment ENV    Build environment (development, production)
echo   -a, --api-url URL        API URL for the build
echo   -t, --tag TAG            Docker image tag (default: latest)
echo   -r, --registry REGISTRY  Docker registry (optional)
echo   -h, --help               Show this help message
echo.
echo Examples:
echo   build-docker.bat -e development -a http://localhost:5000
echo   build-docker.bat -e production -a https://api.example.com -t v1.0.0
exit /b 0

:end
endlocal
