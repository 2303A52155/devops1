@REM Docker Run Helper Script for Windows
@REM This script helps run Docker containers with proper environment variable injection

@echo off
setlocal enabledelayedexpansion

REM Default values
set "ENVIRONMENT=development"
set "API_URL=http://localhost:5000"
set "CONTAINER_NAME="
set "PORT=3000"
set "DETACH="
set "REMOVE="

REM Parse arguments
:parse_args
if "%1"=="" goto parse_end
if "%1"=="-e" (
    set "ENVIRONMENT=%2"
    shift
    shift
    goto parse_args
)
if "%1"=="--environment" (
    set "ENVIRONMENT=%2"
    shift
    shift
    goto parse_args
)
if "%1"=="-a" (
    set "API_URL=%2"
    shift
    shift
    goto parse_args
)
if "%1"=="--api-url" (
    set "API_URL=%2"
    shift
    shift
    goto parse_args
)
if "%1"=="-n" (
    set "CONTAINER_NAME=%2"
    shift
    shift
    goto parse_args
)
if "%1"=="--name" (
    set "CONTAINER_NAME=%2"
    shift
    shift
    goto parse_args
)
if "%1"=="-p" (
    set "PORT=%2"
    shift
    shift
    goto parse_args
)
if "%1"=="--port" (
    set "PORT=%2"
    shift
    shift
    goto parse_args
)
if "%1"=="-d" (
    set "DETACH=-d"
    shift
    goto parse_args
)
if "%1"=="--detach" (
    set "DETACH=-d"
    shift
    goto parse_args
)
if "%1"=="--rm" (
    set "REMOVE=--rm"
    shift
    goto parse_args
)
if "%1"=="-h" (
    goto help
)
if "%1"=="--help" (
    goto help
)
if "!IMAGE_NAME!"=="" (
    set "IMAGE_NAME=%1"
)
shift
goto parse_args

:parse_end

REM Validate image name
if "!IMAGE_NAME!"=="" (
    echo Error: Image name is required
    exit /b 1
)

REM Build docker name parameter
set "NAME_PARAM="
if not "!CONTAINER_NAME!"=="" (
    set "NAME_PARAM=--name !CONTAINER_NAME!"
)

REM Display run information
echo.
echo Docker Run Configuration
echo ================================
echo Image: !IMAGE_NAME!
echo Environment: !ENVIRONMENT!
echo API URL: !API_URL!
echo Port: !PORT!:3000
echo Detach: !DETACH!
echo Remove: !REMOVE!
echo Container Name: !CONTAINER_NAME!
echo.

REM Run the container
echo Starting container...
docker run ^
    !DETACH! ^
    !REMOVE! ^
    !NAME_PARAM! ^
    -p !PORT!:3000 ^
    -e REACT_APP_API_URL=!API_URL! ^
    -e REACT_APP_ENVIRONMENT=!ENVIRONMENT! ^
    -e NODE_ENV=!ENVIRONMENT! ^
    !IMAGE_NAME!

if !errorlevel! equ 0 (
    echo.
    echo Container started successfully
) else (
    echo.
    echo Container failed to start
    exit /b 1
)

goto end

:help
echo Usage: run-docker.bat [OPTIONS] IMAGE_NAME
echo.
echo Options:
echo   -e, --environment ENV    Runtime environment (development, production)
echo   -a, --api-url URL        API URL for runtime
echo   -n, --name NAME          Container name
echo   -p, --port PORT          Port to expose (default: 3000)
echo   -d, --detach             Run in detached mode
echo   --rm                     Automatically remove container on exit
echo   -h, --help               Show this help message
echo.
echo Examples:
echo   run-docker.bat react-finance-app:latest
echo   run-docker.bat -e production -a https://api.example.com -d react-finance-app:latest
exit /b 0

:end
endlocal
