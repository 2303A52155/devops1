#!/bin/bash

# Full Stack Test Script
# Tests development environment with Docker Compose

set -e

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

log_info() {
    echo -e "${BLUE}ℹ️  $1${NC}"
}

log_success() {
    echo -e "${GREEN}✓ $1${NC}"
}

log_error() {
    echo -e "${RED}✗ $1${NC}"
}

# Check if Docker is running
log_info "Checking Docker daemon..."
if ! docker info > /dev/null 2>&1; then
    log_error "Docker daemon is not running"
    exit 1
fi
log_success "Docker daemon is running"

echo ""

# Check if Docker Compose is available
log_info "Checking Docker Compose..."
if ! docker-compose --version > /dev/null 2>&1; then
    log_error "Docker Compose is not installed"
    exit 1
fi
log_success "Docker Compose is available"

echo ""

# Start services
log_info "Starting Docker Compose services..."
docker-compose up -d

# Wait for services to be ready
log_info "Waiting for services to be ready..."
sleep 5

echo ""

# Test React app
log_info "Testing React app...I've successfully created a comprehensive React Frontend Dockerization setup with Environment Variables. Here's what I've built for you:

## ✅ Project Structure Created:

### Core React Application Files:
- **package.json** - Dependencies & scripts
- **public/index.html** - HTML entry point
- **src/App.js** - Main component with API status display
- **src/App.css** - Professional styling
- **src/index.js** - React initialization
- **src/config/apiConfig.js** - Environment variable configuration handler

### Environment Configuration:
- **.env** - Default fallback variables
- **.env.dev** - Development environment (localhost:5000)
- **.env.prod** - Production environment (production API URL)
- **.env.docker** - Docker-specific variable declarations

### Docker Configuration:
- **Dockerfile** - Multi-stage production build
- **Dockerfile.dev** - Development build with hot reloading
- **docker-compose.yml** - Development orchestration
- **docker-compose.prod.yml** - Production orchestration
- **.dockerignore** - Optimized image size

### Helper Scripts:
- **build-docker.sh / .bat** - Build images with environment injection
- **run-docker.sh / .bat** - Run containers with runtime variables
- **test-setup.sh** - Validate container setup
- **validate-env.js** - Environment validation at runtime

### Documentation & Config:
- **.gitignore** - Version control exclusions
- Comprehensive README (coming next)

## 🔑 Key Features Implemented:

1. **Build-Time Environment Variables**: Injected via Docker ARG
2. **Runtime Environment Variables**: Can override via ENV flags
3. **Multi-Stage Docker Build**: Optimized image size for production
4. **Environment Validation**: JavaScript validation & shell script checks
5. **Health Checks**: Docker health probes included
6. **Development/Production Modes**: Separate Dockerfiles & configs
7. **Cross-Platform Scripts**: Bash & Windows batch versions
8. **API Configuration Module**: Singleton pattern for configuration

## 📋 Next Step:

Let me create the comprehensive README and then we'll test the complete setup:
