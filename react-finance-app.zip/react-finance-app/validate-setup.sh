#!/bin/bash

# Final Validation Script
# Comprehensive verification of the Docker setup

set -e

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
MAGENTA='\033[0;35m'
CYAN='\033[0;36m'
NC='\033[0m'

log_info() {
    echo -e "${BLUE}ℹ️  $1${NC}"
}

log_success() {
    echo -e "${GREEN}✓ $1${NC}"
}

log_error() {
    echo -e "${RED}✗ $1${NC}"
}

log_warning() {
    echo -e "${YELLOW}⚠ $1${NC}"
}

log_header() {
    echo ""
    echo -e "${MAGENTA}╔════════════════════════════════════════╗${NC}"
    echo -e "${MAGENTA}║ $1║${NC}"
    echo -e "${MAGENTA}╚════════════════════════════════════════╝${NC}"
    echo ""
}

log_section() {
    echo -e "${CYAN}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
    echo -e "${CYAN}$1${NC}"
    echo -e "${CYAN}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
}

total_checks=0
passed_checks=0
failed_checks=0

check() {
    total_checks=$((total_checks + 1))
    if [ $? -eq 0 ]; then
        passed_checks=$((passed_checks + 1))
        log_success "$1"
    else
        failed_checks=$((failed_checks + 1))
        log_error "$1"
    fi
}

log_header "React Docker Setup Validation"

# 1. File Structure Validation
log_section "1. Checking Project File Structure"

[ -f "package.json" ]; check "package.json exists"
[ -f "README.md" ]; check "README.md exists"
[ -f "QUICKSTART.md" ]; check "QUICKSTART.md exists"
[ -f "DOCKER_REFERENCE.md" ]; check "DOCKER_REFERENCE.md exists"

[ -f "Dockerfile" ]; check "Dockerfile (production) exists"
[ -f "Dockerfile.dev" ]; check "Dockerfile.dev (development) exists"
[ -f "docker-compose.yml" ]; check "docker-compose.yml exists"
[ -f "docker-compose.prod.yml" ]; check "docker-compose.prod.yml exists"

[ -f ".env" ]; check ".env (default) exists"
[ -f ".env.dev" ]; check ".env.dev (development) exists"
[ -f ".env.prod" ]; check ".env.prod (production) exists"

[ -f ".dockerignore" ]; check ".dockerignore exists"
[ -f ".gitignore" ]; check ".gitignore exists"

# 2. Source Code Files
log_section "2. Checking Source Code"

[ -f "public/index.html" ]; check "public/index.html exists"
[ -f "src/index.js" ]; check "src/index.js exists"
[ -f "src/index.css" ]; check "src/index.css exists"
[ -f "src/App.js" ]; check "src/App.js exists"
[ -f "src/App.css" ]; check "src/App.css exists"
[ -f "src/config/apiConfig.js" ]; check "src/config/apiConfig.js exists"

# 3. Helper Scripts
log_section "3. Checking Helper Scripts"

[ -f "validate-env.js" ]; check "validate-env.js exists"
[ -f "build-docker.sh" ]; check "build-docker.sh (Unix) exists"
[ -f "build-docker.bat" ]; check "build-docker.bat (Windows) exists"
[ -f "run-docker.sh" ]; check "run-docker.sh (Unix) exists"
[ -f "run-docker.bat" ]; check "run-docker.bat (Windows) exists"
[ -f "test-setup.sh" ]; check "test-setup.sh exists"
[ -f "test-full-stack.sh" ]; check "test-full-stack.sh exists"

# 4. Environment Variable Validation
log_section "4. Checking Environment Variables"

grep -q "REACT_APP_API_URL" .env; check ".env contains REACT_APP_API_URL"
grep -q "REACT_APP_API_URL" .env.dev; check ".env.dev contains REACT_APP_API_URL"
grep -q "REACT_APP_API_URL" .env.prod; check ".env.prod contains REACT_APP_API_URL"

grep -q "REACT_APP_API_URL" Dockerfile; check "Dockerfile has REACT_APP_API_URL ARG"
grep -q "REACT_APP_API_URL" Dockerfile.dev; check "Dockerfile.dev has REACT_APP_API_URL"

grep -q "ARG REACT_APP_API_URL" Dockerfile; check "Dockerfile uses ARG for REACT_APP_API_URL"
grep -q "ENV REACT_APP_API_URL" Dockerfile; check "Dockerfile sets ENV for REACT_APP_API_URL"

# 5. Docker Configuration
log_section "5. Checking Docker Configuration"

grep -q "version:" docker-compose.yml; check "docker-compose.yml is valid YAML"
grep -q "services:" docker-compose.yml; check "docker-compose.yml has services"
grep -q "REACT_APP_API_URL" docker-compose.yml; check "docker-compose.yml sets environment vars"

grep -q "FROM node" Dockerfile; check "Dockerfile uses Node.js base image"
grep -q "HEALTHCHECK" Dockerfile; check "Dockerfile includes health check"
grep -q "EXPOSE 3000" Dockerfile; check "Dockerfile exposes port 3000"

# 6. Configuration Validation
log_section "6. Validating Configuration Files"

# Check Dockerfile syntax
docker build --dry-run . > /dev/null 2>&1; check "Dockerfile syntax is valid"
docker build --dry-run -f Dockerfile.dev . > /dev/null 2>&1; check "Dockerfile.dev syntax is valid"

# 7. React App Configuration
log_section "7. Checking React App Configuration"

grep -q "apiConfig" src/App.js; check "App.js imports apiConfig"
grep -q "REACT_APP_API_URL" src/config/apiConfig.js; check "apiConfig validates REACT_APP_API_URL"
grep -q "validateEnvironment" src/config/apiConfig.js; check "apiConfig has validation method"

# 8. Permission Checks
log_section "8. Checking File Permissions"

[ -x "build-docker.sh" ] || log_warning "build-docker.sh is not executable"
[ -x "run-docker.sh" ] || log_warning "run-docker.sh is not executable"
[ -x "test-setup.sh" ] || log_warning "test-setup.sh is not executable"

# 9. System Requirements
log_section "9. Checking System Requirements"

command -v docker &> /dev/null; check "Docker is installed"
command -v docker-compose &> /dev/null; check "Docker Compose is installed"

if command -v docker &> /dev/null; then
    docker --version | grep -q "20\|21\|22\|23\|24"; check "Docker version is 20+ (found: $(docker --version | cut -d' ' -f3))"
fi

# 10. Summary
log_section "VALIDATION SUMMARY"

echo -e "${MAGENTA}Total Checks:${NC} $total_checks"
echo -e "${GREEN}Passed:${NC} $passed_checks"
echo -e "${RED}Failed:${NC} $failed_checks"
echo ""

if [ $failed_checks -eq 0 ]; then
    log_success "All checks passed! ✨"
    echo ""
    log_info "Your React Dockerization setup is properly configured."
    echo ""
    echo "Next steps:"
    echo "  1. Review QUICKSTART.md for quick start guide"
    echo "  2. Review README.md for detailed documentation"
    echo "  3. Start development: docker-compose up"
    echo "  4. Open browser: http://localhost:3000"
    echo ""
else
    log_error "$failed_checks checks failed"
    echo ""
    log_info "Please review the errors above and correct any issues."
    exit 1
fi

echo ""
log_header "Setup Complete! Ready to Use 🚀"
