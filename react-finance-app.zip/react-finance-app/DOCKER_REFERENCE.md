# Docker Compose Configuration Reference

## Development Setup (docker-compose.yml)

Designed for local development with hot-reload capabilities and optional mock backend.

### Features:
- ✓ Hot module reloading (HMR) via volume mounts
- ✓ Development environment variables
- ✓ Mount source code for live updates
- ✓ Optional mock backend API service
- ✓ Health checks
- ✓ Interactive terminal support

### Services:

#### react-app (Development)
```yaml
Build Context: Dockerfile.dev
Ports: 3000:3000
Environment: 
  - REACT_APP_API_URL=http://localhost:5000
  - NODE_ENV=development
```

#### backend-api (Optional Mock Service)
```yaml
Image: mockserver/mockserver:latest
Ports: 5000:1080 (MockServer)
Purpose: Mock API for testing without real backend
```

### Usage:
```bash
# Start services
docker-compose up

# In background
docker-compose up -d

# Stop services
docker-compose down

# View logs
docker-compose logs -f

# Rebuild services
docker-compose up --build
```

## Production Setup (docker-compose.prod.yml)

Optimized for production deployments with security and performance focus.

### Features:
- ✓ Optimized production image (multi-stage)
- ✓ Environment-specific configuration
- ✓ Automatic restart policy
- ✓ Network isolation
- ✓ Health checks
- ✓ No unnecessary volume mounts

### Services:

#### react-app (Production)
```yaml
Build: Optimized production Dockerfile
Ports: 3000:3000
Environment:
  - REACT_APP_API_URL=https://api.finance-tracker.com
  - NODE_ENV=production
Restart Policy: unless-stopped
Network: finance-network
```

### Usage:
```bash
# Start services
docker-compose -f docker-compose.prod.yml up -d

# Check status
docker-compose -f docker-compose.prod.yml ps

# View logs
docker-compose -f docker-compose.prod.yml logs -f

# Stop services
docker-compose -f docker-compose.prod.yml down
```

## Environment Variables Explained

### Build-Time Variables
Set during `docker build` via `--build-arg`

```bash
docker build \
  --build-arg REACT_APP_API_URL=http://api.example.com \
  -t myapp .
```

**Characteristics**:
- Set when image is created
- Baked into the image
- Cannot change without rebuilding
- Available at build AND runtime

### Runtime Variables
Set during `docker run` or in docker-compose via `environment`

```bash
docker run -e REACT_APP_API_URL=http://api.example.com myapp
```

**Characteristics**:
- Set when container starts
- Can change between runs
- No rebuild needed
- Can override build-time values

### Variables in React

```javascript
// Build-time variables are embedded in the final bundle
// Available via process.env in the JavaScript
const API_URL = process.env.REACT_APP_API_URL;
```

## Quick Command Reference

### Building Images

```bash
# Development
docker build -f Dockerfile.dev \
  --build-arg REACT_APP_API_URL=http://localhost:5000 \
  -t react-finance-app:dev .

# Production
docker build \
  --build-arg REACT_APP_API_URL=https://api.example.com \
  --build-arg NODE_ENV=production \
  -t react-finance-app:prod .
```

### Running Containers

```bash
# Development (foreground)
docker run -it -p 3000:3000 \
  -e REACT_APP_API_URL=http://localhost:5000 \
  react-finance-app:dev

# Production (background)
docker run -d -p 3000:3000 \
  --name finance-app \
  -e REACT_APP_API_URL=https://api.example.com \
  --restart unless-stopped \
  react-finance-app:prod
```

### Using Docker Compose

```bash
# Development
docker-compose up
docker-compose down

# Production  
docker-compose -f docker-compose.prod.yml up -d
docker-compose -f docker-compose.prod.yml down

# Rebuild
docker-compose up --build
```

### Container Management

```bash
# List running containers
docker ps

# List all containers
docker ps -a

# View logs
docker logs <container_id>
docker logs -f <container_id>  # Follow

# Execute command in container
docker exec <container_id> ls -la

# Stop container
docker stop <container_id>

# Remove container
docker rm <container_id>

# Remove image
docker rmi <image_name>
```

## Common Scenarios

### Scenario 1: Development with Local API

```bash
# Start mock API
docker-compose up backend-api &

# Start React app (configured for localhost:5000)
docker-compose up react-app
```

### Scenario 2: Development with Remote API

```bash
docker-compose up -d  # Edit docker-compose.yml first
sed -i 's|http://localhost:5000|https://dev-api.example.com|g' docker-compose.yml
docker-compose up react-app
```

### Scenario 3: Production Deployment

```bash
docker build \
  --build-arg REACT_APP_API_URL=https://api.example.com \
  --build-arg NODE_ENV=production \
  -t react-finance-app:v1.0.0 .

docker run -d -p 3000:3000 \
  --restart unless-stopped \
  react-finance-app:v1.0.0
```

### Scenario 4: Multiple Environments

```bash
# Development
docker-compose -f docker-compose.dev.yml up

# Staging
docker-compose -f docker-compose.staging.yml up

# Production
docker-compose -f docker-compose.prod.yml up
```

## Networking

### Inside containers:
```bash
# Direct address
http://service-name:port

# Example
http://backend-api:1080/mockserver/health
```

### From host to container:
```bash
# Mapped port
http://localhost:3000
http://127.0.0.1:3000
```

### Container to host (Docker Desktop):
```bash
# Mac/Windows only
http://host.docker.internal:5000
```

## Volumes and Mounts

### Development (Hot Reload)
```yaml
volumes:
  - .:/app              # Mount entire project
  - /app/node_modules   # Keep node_modules separate
```

### Production (Read-Only)
```yaml
# Don't mount volumes - use built-in image content only
```

## Health Checks

### Docker Health Check
```yaml
healthcheck:
  test: ["CMD", "curl", "-f", "http://localhost:3000"]
  interval: 30s
  timeout: 10s
  retries: 3
  start_period: 10s
```

### View Health Status
```bash
docker ps
# NAMES                     STATUS
# react-app                 Up 2 minutes (healthy)
```

## Resource Limits (Optional)

```yaml
services:
  react-app:
    deploy:
      resources:
        limits:
          cpus: '1'
          memory: 512M
        reservations:
          cpus: '0.5'
          memory: 256M
```

## Secrets Management (Production)

```yaml
# Best practice: Use environment files
env_file:
  - .env.production

# Or use Docker secrets
secrets:
  api_url:
    file: ./secrets/api_url.txt
```

## Logging

### View composite logs
```bash
docker-compose logs

# Follow specific service
docker-compose logs -f react-app

# Last N lines
docker-compose logs --tail 50
```

### Configure logging
```yaml
services:
  react-app:
    logging:
      driver: "json-file"
      options:
        max-size: "10m"
        max-file: "3"
```
