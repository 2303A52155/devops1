# Quick Start Guide - React Dockerization with Environment Variables

## 🚀 Get Started in 5 Minutes

### Step 1: Navigate to Project
```bash
cd react-finance-app
```

### Step 2: Start with Docker Compose (Easiest)
```bash
# Development mode
docker-compose up

# Your app will be available at: http://localhost:3000
```

### Step 3: View the App
Open browser and go to: **http://localhost:3000**

You should see:
- ✅ API Status: Attempting to connect
- ✅ Environment Configuration display
- ✅ REACT_APP_API_URL shown

### Step 4: Test Different API URLs

**Stop current containers**:
```bash
docker-compose down
```

**Edit and restart with different API**:
```bash
# Edit docker-compose.yml and change REACT_APP_API_URL
nano docker-compose.yml

# Or use sed to replace
sed -i 's|http://localhost:5000|http://custom-api.com|g' docker-compose.yml

# Restart
docker-compose up --build
```

### Step 5: Production Build

```bash
# Build production image
docker build \
  --build-arg REACT_APP_API_URL=https://api.production.com \
  --build-arg NODE_ENV=production \
  -t react-finance-app:prod .

# Run production container
docker run -d -p 3000:3000 react-finance-app:prod
```

---

## 📌 Common Tasks

### Build Development Image
```bash
# Using build script
./build-docker.sh -e development -a http://localhost:5000

# Or manual
docker build -f Dockerfile.dev \
  --build-arg REACT_APP_API_URL=http://localhost:5000 \
  -t react-finance-app:dev .
```

### Run Development Container
```bash
# Using run script
./run-docker.sh react-finance-app:dev

# Or manual with hot reload
docker run -it -p 3000:3000 \
  -v $(pwd)/src:/app/src \
  -e REACT_APP_API_URL=http://localhost:5000 \
  react-finance-app:dev
```

### Validate Environment
```bash
# Check environment variables are set correctly
docker exec <container_id> env | grep REACT_APP

# Run Node.js validation
docker exec <container_id> node validate-env.js

# Check container logs
docker logs <container_id>
```

### Test API Connectivity
```bash
# From host machine
curl -f http://localhost:3000

# Inside container
docker exec <container_id> curl -f http://localhost:3000
```

---

## 🔧 Environment Variable Cheat Sheet

### Development (.env.dev)
```env
REACT_APP_API_URL=http://localhost:5000
REACT_APP_ENVIRONMENT=development
REACT_APP_DEBUG=true
```

### Production (.env.prod)
```env
REACT_APP_API_URL=https://api.finance-tracker.com
REACT_APP_ENVIRONMENT=production
REACT_APP_DEBUG=false
```

### Docker Override
```bash
docker run -p 3000:3000 \
  -e REACT_APP_API_URL=http://custom-api.com \
  react-finance-app:dev
```

---

## 📊 Architecture

```
┌─────────────────────────────────────────────────────┐
│                   Your Browser                      │
│               http://localhost:3000                 │
└──────────────────┬──────────────────────────────────┘
                   │
                   ▼
┌─────────────────────────────────────────────────────┐
│            Docker Container (React App)             │
│  ┌──────────────────────────────────────────────┐   │
│  │  Environment Variables:                      │   │
│  │  - REACT_APP_API_URL (injected at build)     │   │
│  │  - REACT_APP_ENVIRONMENT                     │   │
│  │  - NODE_ENV                                  │   │
│  └──────────────────────────────────────────────┘   │
│                   │                                 │
│                   ▼                                 │
│  ┌──────────────────────────────────────────────┐   │
│  │  React App (3000)                            │   │
│  │  - apiConfig.js validates ENV                │   │
│  │  - App.js displays status                    │   │
│  └──────────────────────────────────────────────┘   │
└──────────────────┬──────────────────────────────────┘
                   │
                   ▼
        ┌──────────────────────┐
        │   Backend API        │
        │  (from env variable) │
        │ http://api:5000      │
        └──────────────────────┘
```

---

## ✅ Configuration Options

### Option 1: Docker Compose (Recommended)
```bash
docker-compose up                    # Development
docker-compose -f docker-compose.prod.yml up  # Production
```

### Option 2: Helper Scripts
```bash
./build-docker.sh -e production -a https://api.com  # Build
./run-docker.sh react-finance-app:prod              # Run
```

### Option 3: Manual Docker Commands
```bash
docker build --build-arg REACT_APP_API_URL=... -t app .
docker run -e REACT_APP_API_URL=... -p 3000:3000 app
```

---

## 🐛 Troubleshooting

### ❌ "Cannot connect to API"
```bash
# Check environment is set
docker exec <container_id> env | grep REACT_APP_API_URL

# Check API URL in config
docker logs <container_id> | grep "API URL"

# Fix: Pass correct URL
docker run -e REACT_APP_API_URL=http://correct-url:5000 myapp
```

### ❌ "Port 3000 already in use"
```bash
# Use different port
docker run -p 8080:3000 react-finance-app:dev
```

### ❌ "Container exits immediately"
```bash
# Check logs
docker logs <container_id>

# Run interactively to see errors
docker run -it react-finance-app:dev
```

### ❌ "Environment variable not injected"
```bash
# Verify it was set during build
docker build \
  --build-arg REACT_APP_API_URL=http://localhost:5000 \
  -t test .

# And during run
docker run -e REACT_APP_API_URL=http://localhost:5000 test
```

---

## 📚 Next Steps

1. **Read Full README**: `cat README.md` - Complete documentation
2. **Docker Reference**: `cat DOCKER_REFERENCE.md` - Detailed configs
3. **Explore Source**: Check `src/` directory for React code
4. **Customize**: Modify environment variables for your API
5. **Deploy**: Use production settings for real deployments

---

## 🎓 Key Concepts

| Concept | Purpose | Example |
|---------|---------|---------|
| **Build Args** | Set at image creation | `--build-arg REACT_APP_API_URL=...` |
| **Environment Variables** | Set at container runtime | `-e REACT_APP_API_URL=...` |
| **docker-compose.yml** | Orchestrate multiple services | Easy development setup |
| **.env files** | Store configuration | `.env.dev`, `.env.prod` |
| **Dockerfile** | Define image | Multi-stage build |
| **Health Check** | Monitor container | Automatic restart |

---

## 🎉 You're All Set!

Your React application is now:
- ✅ **Containerized** - Runs consistently anywhere
- ✅ **Environment-Aware** - Dev and Prod configs
- ✅ **Validated** - Checks environment variables
- ✅ **Production-Ready** - Multi-stage build & health checks
- ✅ **Well-Documented** - Comprehensive guides

**Happy Containerizing! 🚀**

---

For questions, check:
- README.md - Full documentation
- DOCKER_REFERENCE.md - Configuration details
- Troubleshooting section above
