#!/bin/bash

# Docker Build Helper Script
# This script helps build Docker images with proper environment variable injection

set -e  # Exit on error

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Helper functions
log_info() {
    echo -e "${BLUE}ℹ️  $1${NC}"
}

log_success() {
    echo -e "${GREEN}✓ $1${NC}"
}

log_error() {
    echo -e "${RED}✗ $1${NC}"
}

log_warning() {
    echo -e "${YELLOW}⚠ $1${NC}"
}

# Default values
ENVIRONMENT="development"
API_URL=""
IMAGE_TAG="latest"
REGISTRY=""

# Parse command line arguments
while [[ $# -gt 0 ]]; do
    case $1 in
        -e|--environment)
            ENVIRONMENT="$2"
            shift 2
            ;;
        -a|--api-url)
            API_URL="$2"
            shift 2
            ;;
        -t|--tag)
            IMAGE_TAG="$2"
            shift 2
            ;;
        -r|--registry)
            REGISTRY="$2"
            shift 2
            ;;
        -h|--help)
            cat <<EOF
Usage: ./build-docker.sh [OPTIONS]

Options:
  -e, --environment ENV    Build environment (development, production)
  -a, --api-url URL        API URL for the build
  -t, --tag TAG            Docker image tag (default: latest)
  -r, --registry REGISTRY  Docker registry (optional)
  -h, --help               Show this help message

Examples:
  ./build-docker.sh -e development -a http://localhost:5000
  ./build-docker.sh -e production -a https://api.example.com -t v1.0.0
EOF
            exit 0
            ;;
        *)
            log_error "Unknown option: $1"
            exit 1
            ;;
    esac
done

# Validate API URL
if [ -z "$API_URL" ]; then
    if [ "$ENVIRONMENT" = "production" ]; then
        log_error "API URL is required for production build"
        exit 1
    else
        API_URL="http://localhost:5000"
        log_warning "No API URL specified, using default: $API_URL"
    fi
fi

# Set other variables based on environment
if [ "$ENVIRONMENT" = "production" ]; then
    DEBUG="false"
    NODE_ENV="production"
    DOCKERFILE="Dockerfile"
else
    DEBUG="true"
    NODE_ENV="development"
    DOCKERFILE="Dockerfile.dev"
fi

# Build Docker image name
IMAGE_NAME="react-finance-app"
if [ -n "$REGISTRY" ]; then
    FULL_IMAGE_NAME="${REGISTRY}/${IMAGE_NAME}:${IMAGE_TAG}"
else
    FULL_IMAGE_NAME="${IMAGE_NAME}:${IMAGE_TAG}"
fi

# Display build information
echo ""
log_info "Docker Build Configuration"
echo "================================"
log_info "Environment: $ENVIRONMENT"
log_info "API URL: $API_URL"
log_info "Debug Mode: $DEBUG"
log_info "Node Environment: $NODE_ENV"
log_info "Dockerfile: $DOCKERFILE"
log_info "Image Name: $FULL_IMAGE_NAME"
echo ""

# Confirm before building
read -p "Proceed with build? (y/n) " -n 1 -r
echo
if [[ ! $REPLY =~ ^[Yy]$ ]]; then
    log_warning "Build cancelled"
    exit 0
fi

# Build Docker image
log_info "Building Docker image..."
docker build \
    -f "$DOCKERFILE" \
    -t "$FULL_IMAGE_NAME" \
    --build-arg REACT_APP_API_URL="$API_URL" \
    --build-arg REACT_APP_ENVIRONMENT="$ENVIRONMENT" \
    --build-arg REACT_APP_DEBUG="$DEBUG" \
    --build-arg NODE_ENV="$NODE_ENV" \
    .

if [ $? -eq 0 ]; then
    log_success "Docker image built successfully!"
    log_info "Run the image with:"
    echo "  docker run -p 3000:3000 ${FULL_IMAGE_NAME}"
else
    log_error "Docker build failed!"
    exit 1
fi

echo ""
