# Deployment Guide - React Personal Finance Tracker

Complete guide for deploying the Dockerized React application across different environments.

## Table of Contents
1. [Local Development](#local-development)
2. [Staging Environment](#staging-environment)
3. [Production Deployment](#production-deployment)
4. [CI/CD Integration](#cicd-integration)
5. [Monitoring & Logs](#monitoring--logs)
6. [Rollback Strategy](#rollback-strategy)

## Local Development

### Setup

```bash
# Clone and navigate
cd react-finance-app

# Install dependencies for local development (optional)
npm install

# Start with Docker Compose
docker-compose up

# Or start in background
docker-compose up -d
```

### Configuration

Edit `docker-compose.yml` to customize:
```yaml
environment:
  - REACT_APP_API_URL=http://localhost:5000
  - REACT_APP_ENVIRONMENT=development
  - REACT_APP_DEBUG=true
```

### Access

- Application: http://localhost:3000
- View logs: `docker-compose logs -f react-app`
- Stop: `docker-compose down`

---

## Staging Environment

### Build Staging Image

```bash
docker build \
  --build-arg REACT_APP_API_URL=https://staging-api.example.com \
  --build-arg REACT_APP_ENVIRONMENT=staging \
  --build-arg NODE_ENV=production \
  -t react-finance-app:staging .
```

### Run on Staging Server

```bash
docker run -d \
  --name finance-tracker-staging \
  -p 3000:3000 \
  -e REACT_APP_API_URL=https://staging-api.example.com \
  --restart unless-stopped \
  --log-driver json-file \
  --log-opt max-size=10m \
  --log-opt max-file=3 \
  react-finance-app:staging
```

### Verify Deployment

```bash
# Check status
docker ps | grep finance-tracker-staging

# View logs
docker logs finance-tracker-staging

# Test connectivity
curl -f https://staging.example.com/
```

### Create docker-compose.staging.yml

```yaml
version: '3.8'

services:
  react-app:
    build:
      context: .
      dockerfile: Dockerfile
      args:
        REACT_APP_API_URL: https://staging-api.example.com
        REACT_APP_ENVIRONMENT: staging
        NODE_ENV: production
    container_name: finance-tracker-staging
    ports:
      - "3000:3000"
    environment:
      - REACT_APP_API_URL=https://staging-api.example.com
      - REACT_APP_ENVIRONMENT=staging
    restart: unless-stopped
    healthcheck:
      test: ["CMD", "curl", "-f", "http://localhost:3000"]
      interval: 30s
      timeout: 10s
      retries: 3
    networks:
      - staging-net

networks:
  staging-net:
    driver: bridge
```

---

## Production Deployment

### Prerequisites

- Stable production API endpoint
- Domain name and SSL certificate
- Production-grade server
- Monitoring and logging solution

### Build Production Image

```bash
# With Git tag
TAG=$(git describe --tags --always)

docker build \
  --build-arg REACT_APP_API_URL=https://api.finance-tracker.com \
  --build-arg REACT_APP_ENVIRONMENT=production \
  --build-arg NODE_ENV=production \
  -t react-finance-app:${TAG} \
  -t react-finance-app:latest \
  .

# Tag for registry
docker tag react-finance-app:${TAG} registry.example.com/react-finance-app:${TAG}
docker tag react-finance-app:latest registry.example.com/react-finance-app:latest
```

### Push to Registry

```bash
# Login to registry
docker login registry.example.com

# Push images
docker push registry.example.com/react-finance-app:${TAG}
docker push registry.example.com/react-finance-app:latest
```

### Deploy with docker-compose.prod.yml

```yaml
version: '3.8'

services:
  react-app:
    image: registry.example.com/react-finance-app:latest
    pull_policy: always
    container_name: finance-tracker-prod
    ports:
      - "3000:3000"
    environment:
      - REACT_APP_API_URL=https://api.finance-tracker.com
      - REACT_APP_ENVIRONMENT=production
      - NODE_ENV=production
    restart: always
    healthcheck:
      test: ["CMD", "curl", "-f", "http://localhost:3000"]
      interval: 30s
      timeout: 10s
      retries: 3
      start_period: 10s
    resources:
      limits:
        cpus: '1'
        memory: 512M
      reservations:
        cpus: '0.5'
        memory: 256M
    networks:
      - prod-net
    logging:
      driver: "json-file"
      options:
        max-size: "10m"
        max-file: "3"

networks:
  prod-net:
    driver: bridge
```

### Deploy

```bash
# Pull latest image
docker-compose -f docker-compose.prod.yml pull

# Start services
docker-compose -f docker-compose.prod.yml up -d

# Verify
docker-compose -f docker-compose.prod.yml ps
```

### Post-Deployment Checks

```bash
# Check health
curl -f https://api.finance-tracker.com/health

# View recent logs
docker-compose -f docker-compose.prod.yml logs --tail 50

# Monitor metrics
docker stats
```

---

## CI/CD Integration

### GitHub Actions Example

Create `.github/workflows/deploy.yml`:

```yaml
name: Deploy React App

on:
  push:
    branches:
      - main
      - develop
  tags:
    - 'v*'

jobs:
  build-and-deploy:
    runs-on: ubuntu-latest
    
    steps:
      - uses: actions/checkout@v2
      
      - name: Set up Docker Buildx
        uses: docker/setup-buildx-action@v1
      
      - name: Determine environment
        id: env
        run: |
          if [[ $GITHUB_REF == refs/heads/main ]]; then
            echo "ENVIRONMENT=production" >> $GITHUB_OUTPUT
            echo "API_URL=https://api.finance-tracker.com" >> $GITHUB_OUTPUT
          elif [[ $GITHUB_REF == refs/heads/develop ]]; then
            echo "ENVIRONMENT=staging" >> $GITHUB_OUTPUT
            echo "API_URL=https://staging-api.example.com" >> $GITHUB_OUTPUT
          fi
      
      - name: Build and push Docker image
        uses: docker/build-push-action@v2
        with:
          context: .
          push: true
          tags: |
            ${{ secrets.REGISTRY_URL }}/react-finance-app:latest
            ${{ secrets.REGISTRY_URL }}/react-finance-app:${{ github.sha }}
          build-args: |
            REACT_APP_API_URL=${{ steps.env.outputs.API_URL }}
            REACT_APP_ENVIRONMENT=${{ steps.env.outputs.ENVIRONMENT }}
            NODE_ENV=production
          registry: ${{ secrets.REGISTRY_URL }}
          username: ${{ secrets.REGISTRY_USER }}
          password: ${{ secrets.REGISTRY_PASSWORD }}
      
      - name: Deploy to server
        if: github.ref == 'refs/heads/main'
        uses: appleboy/ssh-action@master
        with:
          host: ${{ secrets.PROD_SERVER_HOST }}
          username: ${{ secrets.PROD_SERVER_USER }}
          key: ${{ secrets.PROD_SERVER_KEY }}
          script: |
            cd /app/react-finance-app
            docker-compose -f docker-compose.prod.yml pull
            docker-compose -f docker-compose.prod.yml up -d
```

### Jenkins Pipeline Example

Create `Jenkinsfile`:

```groovy
pipeline {
    agent any
    
    environment {
        REGISTRY = credentials('docker-registry')
        API_URL = credentials('api-url-${BRANCH_NAME}')
    }
    
    stages {
        stage('Build') {
            steps {
                script {
                    sh '''
                        docker build \
                          --build-arg REACT_APP_API_URL=${API_URL} \
                          --build-arg NODE_ENV=production \
                          -t react-finance-app:${BUILD_NUMBER} .
                    '''
                }
            }
        }
        
        stage('Test') {
            steps {
                script {
                    sh '''
                        docker run --rm \
                          react-finance-app:${BUILD_NUMBER} \
                          npm run validate-env
                    '''
                }
            }
        }
        
        stage('Push') {
            when {
                branch 'main'
            }
            steps {
                script {
                    sh '''
                        docker tag react-finance-app:${BUILD_NUMBER} \
                          ${REGISTRY}/react-finance-app:latest
                        docker push ${REGISTRY}/react-finance-app:latest
                    '''
                }
            }
        }
        
        stage('Deploy') {
            when {
                branch 'main'
            }
            steps {
                script {
                    sh '''
                        ssh -i ${PROD_KEY} ${PROD_USER}@${PROD_HOST} \
                          "cd /app && docker-compose pull && \
                          docker-compose up -d"
                    '''
                }
            }
        }
    }
    
    post {
        always {
            sh 'docker rmi react-finance-app:${BUILD_NUMBER}'
        }
    }
}
```

---

## Monitoring & Logs

### View Logs

```bash
# Real-time logs
docker-compose logs -f react-app

# Last N lines
docker-compose logs --tail 50 react-app

# With timestamps
docker-compose logs -f --timestamps react-app
```

### Health Checks

```bash
# Check container health
docker ps --format "table {{.Names}}\t{{.Status}}"

# Manual health test
curl -f http://localhost:3000/
```

### Metrics

```bash
# CPU and memory usage
docker stats

# Image size
docker images | grep react-finance-app
```

### External Logging

Forward logs to ELK Stack, Datadog, etc.:

```yaml
services:
  react-app:
    logging:
      driver: splunk
      options:
        splunk-token: ${SPLUNK_TOKEN}
        splunk-url: https://your-splunk-instance.com
        tag: react-app
```

---

## Rollback Strategy

### Quick Rollback

```bash
# Keep previous image tag
docker image ls | grep react-finance-app

# Stop current and run previous version
docker-compose down
docker-compose -f docker-compose.prod.yml up -d -e DOCKER_IMAGE_TAG=v1.2.0
```

### Blue-Green Deployment

```bash
# Run new version (green)
docker run -d \
  --name finance-tracker-green \
  -p 3001:3000 \
  -e REACT_APP_API_URL=... \
  react-finance-app:new-version

# Test green
curl -f http://localhost:3001

# Switch to green (update nginx/load balancer)
# Rollback if needed:
docker rename finance-tracker-green finance-tracker-green-backup
docker rename finance-tracker-blue finance-tracker
```

### Canary Deployment

```bash
# Run with traffic split
# 90% to production (blue)
# 10% to new version (canary)
# Monitor metrics
# If good, increase % and eventually replace
```

---

## Best Practices Checklist

- [ ] Use semantic versioning for images (v1.0.0, not `latest`)
- [ ] Always pull latest image before deploying
- [ ] Test in staging environment first
- [ ] Monitor logs and metrics post-deployment
- [ ] Keep previous versions readily available for rollback
- [ ] Document API URL changes
- [ ] Have incident response plan
- [ ] Regular backups of configuration
- [ ] Update Docker security patches regularly
- [ ] Use health checks for automatic recovery

---

## Quick Reference

| Task | Command |
|------|---------|
| Build for production | `docker build --build-arg REACT_APP_API_URL=... -t app:v1.0.0 .` |
| Push to registry | `docker push registry/app:v1.0.0` |
| Deploy | `docker-compose -f docker-compose.prod.yml up -d` |
| View logs | `docker-compose logs -f` |
| Check health | `docker ps` |
| Rollback | `docker-compose down && docker-compose up -d` (with previous image) |

---

For more information, see:
- [README.md](README.md) - Complete documentation
- [QUICKSTART.md](QUICKSTART.md) - Quick start guide
- [DOCKER_REFERENCE.md](DOCKER_REFERENCE.md) - Docker configuration reference
