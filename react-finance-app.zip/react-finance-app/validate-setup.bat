#!/bin/bash

# Windows PowerShell equivalent validation script
# For Windows users without bash - can be adapted to Windows batch

@echo off
setlocal enabledelayedexpansion

REM Colors (limited in Windows CMD)
set "GREEN=[92m"
set "RED=[91m"
set "YELLOW=[93m"
set "BLUE=[94m"
set "MAGENTA=[95m"
set "CYAN=[96m"
set "NC=[0m"

REM Initialize counters
set /a total_checks=0
set /a passed_checks=0
set /a failed_checks=0

REM ===== FILE EXISTENCE CHECKS =====
echo.
echo Checking Project File Structure...
echo =========================================

if exist package.json (
    echo [OK] package.json exists
    set /a passed_checks+=1
) else (
    echo [ERROR] package.json NOT found
    set /a failed_checks+=1
)
set /a total_checks+=1

if exist Dockerfile (
    echo [OK] Dockerfile exists
    set /a passed_checks+=1
) else (
    echo [ERROR] Dockerfile NOT found
    set /a failed_checks+=1
)
set /a total_checks+=1

if exist Dockerfile.dev (
    echo [OK] Dockerfile.dev exists
    set /a passed_checks+=1
) else (
    echo [ERROR] Dockerfile.dev NOT found
    set /a failed_checks+=1
)
set /a total_checks+=1

if exist docker-compose.yml (
    echo [OK] docker-compose.yml exists
    set /a passed_checks+=1
) else (
    echo [ERROR] docker-compose.yml NOT found
    set /a failed_checks+=1
)
set /a total_checks+=1

if exist .env (
    echo [OK] .env exists
    set /a passed_checks+=1
) else (
    echo [ERROR] .env NOT found
    set /a failed_checks+=1
)
set /a total_checks+=1

if exist .env.dev (
    echo [OK] .env.dev exists
    set /a passed_checks+=1
) else (
    echo [ERROR] .env.dev NOT found
    set /a failed_checks+=1
)
set /a total_checks+=1

if exist .env.prod (
    echo [OK] .env.prod exists
    set /a passed_checks+=1
) else (
    echo [ERROR] .env.prod NOT found
    set /a failed_checks+=1
)
set /a total_checks+=1

if exist README.md (
    echo [OK] README.md exists
    set /a passed_checks+=1
) else (
    echo [ERROR] README.md NOT found
    set /a failed_checks+=1
)
set /a total_checks+=1

echo.
echo Checking Source Code...
echo =========================================

if exist "src\App.js" (
    echo [OK] src\App.js exists
    set /a passed_checks+=1
) else (
    echo [ERROR] src\App.js NOT found
    set /a failed_checks+=1
)
set /a total_checks+=1

if exist "src\config\apiConfig.js" (
    echo [OK] src\config\apiConfig.js exists
    set /a passed_checks+=1
) else (
    echo [ERROR] src\config\apiConfig.js NOT found
    set /a failed_checks+=1
)
set /a total_checks+=1

if exist "public\index.html" (
    echo [OK] public\index.html exists
    set /a passed_checks+=1
) else (
    echo [ERROR] public\index.html NOT found
    set /a failed_checks+=1
)
set /a total_checks+=1

echo.
echo Checking Helper Scripts...
echo =========================================

if exist validate-env.js (
    echo [OK] validate-env.js exists
    set /a passed_checks+=1
) else (
    echo [ERROR] validate-env.js NOT found
    set /a failed_checks+=1
)
set /a total_checks+=1

if exist build-docker.bat (
    echo [OK] build-docker.bat exists
    set /a passed_checks+=1
) else (
    echo [ERROR] build-docker.bat NOT found
    set /a failed_checks+=1
)
set /a total_checks+=1

if exist run-docker.bat (
    echo [OK] run-docker.bat exists
    set /a passed_checks+=1
) else (
    echo [ERROR] run-docker.bat NOT found
    set /a failed_checks+=1
)
set /a total_checks+=1

echo.
echo =========================================
echo VALIDATION SUMMARY
echo =========================================
echo Total Checks: !total_checks!
echo Passed: !passed_checks!
echo Failed: !failed_checks!
echo.

if !failed_checks! equ 0 (
    echo [SUCCESS] All checks passed!
    echo.
    echo Your React Dockerization setup is properly configured.
    echo.
    echo Next steps:
    echo   1. Review QUICKSTART.md for quick start guide
    echo   2. Review README.md for detailed documentation
    echo   3. Start development: docker-compose up
    echo   4. Open browser: http://localhost:3000
    echo.
) else (
    echo [ERROR] !failed_checks! checks failed
    echo.
    echo Please review the errors above and correct any issues.
    exit /b 1
)

endlocal
