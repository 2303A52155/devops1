/**
 * API Configuration
 * This module handles reading and validating environment variables
 * for API communication across different environments
 */

class APIConfig {
  constructor() {
    this.validateEnvironment();
  }

  /**
   * Validate that required environment variables are set
   * Throws error if REACT_APP_API_URL is missing
   */
  validateEnvironment() {
    const requiredVars = ['REACT_APP_API_URL'];
    const missing = [];

    requiredVars.forEach(varName => {
      if (!process.env[varName]) {
        missing.push(varName);
      }
    });

    if (missing.length > 0) {
      console.error(
        'Missing required environment variables:',
        missing.join(', ')
      );
      throw new Error(
        `Missing required environment variables: ${missing.join(', ')}`
      );
    }
  }

  /**
   * Get the API base URL from environment variables
   * @returns {string} The API URL
   */
  getApiUrl() {
    return process.env.REACT_APP_API_URL || 'http://localhost:5000';
  }

  /**
   * Get the environment (development, production, etc)
   * @returns {string} The environment
   */
  getEnvironment() {
    return process.env.NODE_ENV || 'development';
  }

  /**
   * Check if running in development environment
   * @returns {boolean}
   */
  isDevelopment() {
    return this.getEnvironment() === 'development';
  }

  /**
   * Check if running in production environment
   * @returns {boolean}
   */
  isProduction() {
    return this.getEnvironment() === 'production';
  }

  /**
   * Get all environment-related config
   * @returns {object} Configuration object
   */
  getConfig() {
    return {
      apiUrl: this.getApiUrl(),
      environment: this.getEnvironment(),
      isDevelopment: this.isDevelopment(),
      isProduction: this.isProduction(),
      allEnvVars: Object.keys(process.env)
        .filter(key => key.startsWith('REACT_APP_'))
        .reduce((acc, key) => {
          acc[key] = process.env[key];
          return acc;
        }, {})
    };
  }

  /**
   * Log configuration info (safe for console output)
   */
  logConfig() {
    const config = this.getConfig();
    console.log('=== API Configuration ===');
    console.log('Environment:', config.environment);
    console.log('API URL:', config.apiUrl);
    console.log('Environment Variables:', config.allEnvVars);
    console.log('========================');
  }
}

// Create singleton instance
const apiConfig = new APIConfig();

export default apiConfig;
