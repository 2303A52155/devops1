import React, { useState, useEffect } from 'react';
import axios from 'axios';
import apiConfig from './config/apiConfig';
import './App.css';

function App() {
  const [apiStatus, setApiStatus] = useState('loading');
  const [apiResponse, setApiResponse] = useState(null);
  const [error, setError] = useState(null);
  const [config, setConfig] = useState(null);

  useEffect(() => {
    // Log configuration on mount
    apiConfig.logConfig();
    setConfig(apiConfig.getConfig());

    // Test API connectivity
    testApiConnection();
  }, []);

  const testApiConnection = async () => {
    try {
      setApiStatus('loading');
      setError(null);

      const apiUrl = apiConfig.getApiUrl();
      console.log('Testing API connection to:', apiUrl);

      // Create an axios instance with the API URL
      const apiClient = axios.create({
        baseURL: apiUrl,
        timeout: 5000,
      });

      // Try to connect to the API health endpoint
      const response = await apiClient.get('/health');
      setApiResponse(response.data);
      setApiStatus('success');
      console.log('API connection successful:', response.data);
    } catch (err) {
      console.error('API connection failed:', err.message);
      setError(
        err.message || 'Failed to connect to the API'
      );
      setApiStatus('error');
      // Don't throw error, just show it in UI
    }
  };

  const handleRetry = () => {
    testApiConnection();
  };

  if (!config) {
    return <div className="app-container">Loading configuration...</div>;
  }

  return (
    <div className="app-container">
      <div className="header">
        <h1>💰 Personal Finance Tracker</h1>
        <p className="subtitle">
          Manage your finances with environment-aware configuration
        </p>
      </div>

      {/* API Status Section */}
      <div className={`api-status ${apiStatus}`}>
        <h2>
          <span className={`status-indicator ${apiStatus === 'success' ? 'online' : apiStatus === 'error' ? 'offline' : 'loading'}`}></span>
          API Status: {apiStatus.charAt(0).toUpperCase() + apiStatus.slice(1)}
        </h2>

        <p>
          <strong>API Base URL:</strong>
        </p>
        <div className="api-url">{config.apiUrl}</div>

        {apiStatus === 'success' && apiResponse && (
          <div className="success-message">
            ✓ Successfully connected to the backend API
            <div style={{ marginTop: '10px', fontSize: '12px' }}>
              Response: {JSON.stringify(apiResponse, null, 2)}
            </div>
          </div>
        )}

        {apiStatus === 'error' && error && (
          <div className="error-message">
            ✗ Connection Error: {error}
            <div style={{ marginTop: '10px', fontSize: '12px' }}>
              Make sure the backend API is running at {config.apiUrl}
            </div>
          </div>
        )}

        {apiStatus === 'loading' && (
          <div style={{ marginTop: '10px' }}>
            <span className="loading">⟳</span> Testing connection...
          </div>
        )}

        <button className="button" onClick={handleRetry}>
          Retry Connection
        </button>
      </div>

      {/* Environment Configuration Section */}
      <div className="env-info">
        <h2>Environment Configuration</h2>
        <ul className="env-list">
          <li>
            <strong>NODE_ENV:</strong> {config.environment}
          </li>
          <li>
            <strong>REACT_APP_API_URL:</strong> {config.apiUrl}
          </li>
          <li>
            <strong>Is Production:</strong> {config.isProduction ? 'Yes' : 'No'}
          </li>
          <li>
            <strong>Is Development:</strong> {config.isDevelopment ? 'Yes' : 'No'}
          </li>
        </ul>

        {Object.keys(config.allEnvVars).length > 0 && (
          <div style={{ marginTop: '15px' }}>
            <h3 style={{ fontSize: '14px', marginBottom: '10px' }}>
              All REACT_APP_* Variables:
            </h3>
            <ul className="env-list">
              {Object.entries(config.allEnvVars).map(([key, value]) => (
                <li key={key}>
                  <strong>{key}:</strong> {value}
                </li>
              ))}
            </ul>
          </div>
        )}
      </div>

      {/* Quick Start Instructions */}
      <div className="env-info" style={{ backgroundColor: '#f0f9ff', borderLeft: '4px solid #3b82f6' }}>
        <h2>ℹ️ Quick Start</h2>
        <p>This React app is configured with environment variables for different deployment scenarios:</p>
        <ul style={{ marginLeft: '20px', marginTop: '10px' }}>
          <li><strong>Development:</strong> npm start (uses .env.dev)</li>
          <li><strong>Production:</strong> npm run build (uses .env.prod)</li>
          <li><strong>Docker:</strong> Environment variables are injected at build time</li>
        </ul>
        <p style={{ marginTop: '15px', fontSize: '13px', color: '#666' }}>
          The API URL shown above is read from the REACT_APP_API_URL environment variable
          and injected during the Docker build process.
        </p>
      </div>
    </div>
  );
}

export default App;
