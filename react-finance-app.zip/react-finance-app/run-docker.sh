#!/bin/bash

# Docker Run Helper Script
# This script helps run Docker containers with proper environment variable injection

set -e

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

log_info() {
    echo -e "${BLUE}ℹ️  $1${NC}"
}

log_success() {
    echo -e "${GREEN}✓ $1${NC}"
}

log_error() {
    echo -e "${RED}✗ $1${NC}"
}

# Default values
ENVIRONMENT="development"
API_URL="http://localhost:5000"
CONTAINER_NAME=""
PORT="3000"
DETACH=false
REMOVE=false

# Parse command line arguments
while [[ $# -gt 0 ]]; do
    case $1 in
        -e|--environment)
            ENVIRONMENT="$2"
            shift 2
            ;;
        -a|--api-url)
            API_URL="$2"
            shift 2
            ;;
        -n|--name)
            CONTAINER_NAME="$2"
            shift 2
            ;;
        -p|--port)
            PORT="$2"
            shift 2
            ;;
        -d|--detach)
            DETACH=true
            shift
            ;;
        --rm)
            REMOVE=true
            shift
            ;;
        -h|--help)
            cat <<EOF
Usage: ./run-docker.sh [OPTIONS] IMAGE_NAME

Options:
  -e, --environment ENV    Runtime environment (development, production)
  -a, --api-url URL        API URL for runtime
  -n, --name NAME          Container name
  -p, --port PORT          Port to expose (default: 3000)
  -d, --detach             Run in detached mode
  --rm                     Automatically remove container on exit
  -h, --help               Show this help message

Examples:
  ./run-docker.sh react-finance-app:latest
  ./run-docker.sh -e production -a https://api.example.com -d react-finance-app:latest
EOF
            exit 0
            ;;
        *)
            # Assume it's the image name
            IMAGE_NAME="$1"
            shift
            ;;
    esac
done

# Validate image name
if [ -z "$IMAGE_NAME" ]; then
    log_error "Image name is required"
    exit 1
fi

# Build docker run command
DOCKER_CMD="docker run"

if [ "$DETACH" = true ]; then
    DOCKER_CMD="$DOCKER_CMD -d"
fi

if [ "$REMOVE" = true ]; then
    DOCKER_CMD="$DOCKER_CMD --rm"
fi

if [ -n "$CONTAINER_NAME" ]; then
    DOCKER_CMD="$DOCKER_CMD --name $CONTAINER_NAME"
fi

DOCKER_CMD="$DOCKER_CMD -p $PORT:3000"
DOCKER_CMD="$DOCKER_CMD -e REACT_APP_API_URL=$API_URL"
DOCKER_CMD="$DOCKER_CMD -e REACT_APP_ENVIRONMENT=$ENVIRONMENT"
DOCKER_CMD="$DOCKER_CMD -e NODE_ENV=$ENVIRONMENT"
DOCKER_CMD="$DOCKER_CMD $IMAGE_NAME"

# Display run information
echo ""
log_info "Docker Run Configuration"
echo "================================"
log_info "Image: $IMAGE_NAME"
log_info "Environment: $ENVIRONMENT"
log_info "API URL: $API_URL"
log_info "Port: $PORT:3000"
log_info "Detach: $DETACH"
log_info "Remove: $REMOVE"
log_info "Container Name: ${CONTAINER_NAME:-(auto-generated)}"
echo ""
log_info "Command: $DOCKER_CMD"
echo ""

# Run the container
log_info "Starting container..."
eval $DOCKER_CMD

if [ "$DETACH" = true ]; then
    log_success "Container started in detached mode"
    log_info "View logs with: docker logs $CONTAINER_NAME"
else
    log_success "Container started"
fi

echo ""
