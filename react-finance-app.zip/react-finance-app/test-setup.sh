#!/bin/bash

# Test Script - Verify API connectivity from Docker container
# This script tests the containerized React app's ability to communicate with the backend API

set -e

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

log_info() {
    echo -e "${BLUE}ℹ️  $1${NC}"
}

log_success() {
    echo -e "${GREEN}✓ $1${NC}"
}

log_error() {
    echo -e "${RED}✗ $1${NC}"
}

log_warning() {
    echo -e "${YELLOW}⚠ $1${NC}"
}

# Parameters
CONTAINER_ID="${1:-}"
API_URL="${2:-http://localhost:5000}"

if [ -z "$CONTAINER_ID" ]; then
    log_error "Container ID or name is required"
    echo "Usage: ./test-setup.sh <container_id> [api_url]"
    exit 1
fi

echo ""
log_info "Testing Docker Container Setup"
echo "====================================="
log_info "Container ID: $CONTAINER_ID"
log_info "API URL: $API_URL"
echo ""

# Test 1: Check if container is running
log_info "Test 1: Checking container status..."
if docker ps | grep -q "$CONTAINER_ID"; then
    log_success "Container is running"
else
    log_error "Container is not running"
    exit 1
fi

# Test 2: Check if app is listening on port 3000
log_info "Test 2: Checking if app is listening on port 3000..."
if docker exec "$CONTAINER_ID" curl -f http://localhost:3000 > /dev/null 2>&1; then
    log_success "App is listening on port 3000"
else
    log_error "App is not responding on port 3000"
    exit 1
fi

# Test 3: Check environment variables inside container
log_info "Test 3: Checking environment variables inside container..."
ENV_CHECK=$(docker exec "$CONTAINER_ID" sh -c 'echo $REACT_APP_API_URL')
if [ -n "$ENV_CHECK" ]; then
    log_success "REACT_APP_API_URL is set to: $ENV_CHECK"
else
    log_error "REACT_APP_API_URL is not set"
    exit 1
fi

# Test 4: Check if app can connect to backend API
log_info "Test 4: Verifying backend API configuration..."
APP_API_URL=$(docker exec "$CONTAINER_ID" sh -c 'echo $REACT_APP_API_URL')
if [ "$APP_API_URL" = "$API_URL" ]; then
    log_success "API URL correctly configured: $APP_API_URL"
else
    log_warning "API URL mismatch. Expected: $API_URL, Got: $APP_API_URL"
fi

# Test 5: Check container logs for errors
log_info "Test 5: Checking container logs for errors..."
ERRORS=$(docker logs "$CONTAINER_ID" 2>&1 | grep -i "error" | wc -l || true)
if [ "$ERRORS" -eq 0 ]; then
    log_success "No errors found in container logs"
else
    log_warning "Found $ERRORS errors in container logs"
    log_info "Last 5 log entries:"
    docker logs --tail 5 "$CONTAINER_ID" 2>&1 | while read line; do
        echo "  $line"
    done
fi

# Summary
echo ""
log_success "All tests completed!"
echo ""
