#!/usr/bin/env node

/**
 * Environment Variable Validation Script
 * This script validates that required environment variables are set before the app starts
 */

const fs = require('fs');
const path = require('path');

// ANSI color codes for console output
const colors = {
  reset: '\x1b[0m',
  bright: '\x1b[1m',
  red: '\x1b[31m',
  green: '\x1b[32m',
  yellow: '\x1b[33m',
  blue: '\x1b[34m',
  cyan: '\x1b[36m',
};

function log(message, color = 'reset') {
  console.log(`${colors[color]}${message}${colors.reset}`);
}

function logSection(title) {
  log(title, 'bright');
  log('='.repeat(title.length), 'cyan');
}

function checkEnvironment() {
  logSection('🔍 Environment Variable Validation');
  console.log('');

  // Required environment variables
  const requiredVars = [
    'REACT_APP_API_URL',
  ];

  // Optional environment variables
  const optionalVars = [
    'REACT_APP_ENVIRONMENT',
    'REACT_APP_DEBUG',
    'NODE_ENV',
  ];

  let hasErrors = false;
  let hasWarnings = false;

  // Check required variables
  log('Required Variables:', 'bright');
  requiredVars.forEach(varName => {
    const value = process.env[varName];
    if (!value) {
      log(`  ✗ ${varName}: NOT SET`, 'red');
      hasErrors = true;
    } else {
      log(`  ✓ ${varName}: ${value}`, 'green');
    }
  });

  console.log('');

  // Check optional variables
  log('Optional Variables:', 'bright');
  optionalVars.forEach(varName => {
    const value = process.env[varName];
    if (!value) {
      log(`  ⚠ ${varName}: NOT SET (will use default)`, 'yellow');
      hasWarnings = true;
    } else {
      log(`  ✓ ${varName}: ${value}`, 'green');
    }
  });

  console.log('');

  // Show all REACT_APP_* variables
  const reactAppVars = Object.keys(process.env)
    .filter(key => key.startsWith('REACT_APP_'))
    .sort();

  if (reactAppVars.length > 0) {
    log('All REACT_APP_* Variables:', 'bright');
    reactAppVars.forEach(varName => {
      log(`  ${varName}=${process.env[varName]}`, 'cyan');
    });
    console.log('');
  }

  // Summary
  logSection('Summary');
  if (hasErrors) {
    log('❌ VALIDATION FAILED: Missing required environment variables', 'red');
    log('Please set the following variables before running the app:', 'red');
    requiredVars.forEach(varName => {
      if (!process.env[varName]) {
        log(`  - ${varName}`, 'red');
      }
    });
    process.exit(1);
  } else if (hasWarnings) {
    log('⚠️  VALIDATION WARNING: Some optional variables are not set', 'yellow');
    log('The app will continue with default values', 'yellow');
  } else {
    log('✅ ALL VALIDATIONS PASSED', 'green');
  }

  console.log('');
  return !hasErrors;
}

// Run validation
try {
  checkEnvironment();
} catch (error) {
  log(`Error during validation: ${error.message}`, 'red');
  process.exit(1);
}
